
  # Bharat Biz-Agent Features Overview

  This is a code bundle for Bharat Biz-Agent Features Overview. The original project is available at https://www.figma.com/design/24ISIexisbzttznuI4DLUq/Bharat-Biz-Agent-Features-Overview.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  